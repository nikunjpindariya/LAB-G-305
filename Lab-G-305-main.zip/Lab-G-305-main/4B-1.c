#include<stdio.h>

void main(){

	float h,b;
	printf("Enter Hight:");
	scanf("%f",&h);
	printf("Enter Base length:");
	scanf("%f",&b);
	printf("area of triangle = %f unit sq.",h*b*1/2);
    
}