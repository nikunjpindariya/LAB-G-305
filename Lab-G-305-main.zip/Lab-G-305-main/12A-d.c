#include<stdio.h>

void main(){
    int i,j,k=5;
    for(i=1;i<=5;i++)
    {
        for(k=5;k>i;k--){
        
    }
    {
        for(j=1;j<=i;j++)
    printf(" %d", i);

    }
    printf("\n");

    }

}