#include<stdio.h>

void main(){
    printf("a=3,b=7");
    printf("\nSum = 10");
    
}