#include<stdio.h>

void main(){

    int f,i;
    printf("Enter Feet:- ");
    scanf(" %d" ,&f);
    printf("Enter Inches:- ");
    scanf(" %d" ,&i);
    printf("Feet = Inches %d" ,i=f*12);

}