#include<stdio.h>

void main(){

    int a;
    printf("Enter number a= ");
    scanf(" %d" ,&a);
    if(a>0){
        printf("The number is POSITIVE ");

    }
    else{
        printf("The number is NEGATIVE ");
        
    }
}