#include<stdio.h>

void main(){
    printf("ADDRESS:-");
    printf("\nFlat-506");
    printf("\nRaghuul Apartment");
    printf("\nNear Gurukrupa Hotel");
    printf("\nJamnagar");
    printf("\nGujarat");
    printf("\nPincode:- 361006");

}