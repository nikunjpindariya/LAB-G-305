#include<stdio.h>

void main(){
    
	float a,b,c;
	printf("Enter number:");
	scanf("%f",&a);
	printf("Enter number:");
	scanf("%f",&b);
	printf("Enter number:");
	scanf("%f",&c);
	printf("Average = %f",a/3+b/3+c/3);

}