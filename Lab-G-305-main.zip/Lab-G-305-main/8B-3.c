#include"stdio.h"
void main(){
	int i=1,count=1;
	while(count<=50){
		printf("%d\t",i);
		i=i+3;
		count=count+1;
	}
}