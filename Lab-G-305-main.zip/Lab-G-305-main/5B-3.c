#include<stdio.h>

void main(){

	int a;
	printf("Enter a number 'a': ");
	scanf("%d",&a);
	printf("ax2= %d\n",a<<1);
	printf("a/2= %d\n",a>>1);
    
}