#include<stdio.h>

void main(){
	if(printf("Hello world")){}
}
