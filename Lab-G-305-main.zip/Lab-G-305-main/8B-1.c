#include<stdio.h>
#include<math.h>
int main(){
	int i=0;
	while(i<=9){
		printf("%lf is sq.root of %d\n",sqrt(i),i);
		i++;
	}
	return 0;
}