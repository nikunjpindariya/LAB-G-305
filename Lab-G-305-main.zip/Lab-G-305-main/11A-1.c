#include<stdio.h>
void main(){
	int i,n;
	printf("enter a no.: ");
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		printf("%d\t",i);
	}
}