#include<stdio.h>

void main(){

    int a;
    printf("Enter number a= ");
    scanf(" %d" ,&a);
    if(a%2==0){
        printf("The number is EVEN ");

    }
    else{
        printf("The number is ODD ");
        
    }
}