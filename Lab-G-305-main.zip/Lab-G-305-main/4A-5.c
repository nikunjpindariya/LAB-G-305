#include<stdio.h>

void main(){

	float r;
	printf("Enter Radius of Circle:");
	scanf("%f",&r);
	printf("Area = %f unit sq.",3.14*r*r);
    
}