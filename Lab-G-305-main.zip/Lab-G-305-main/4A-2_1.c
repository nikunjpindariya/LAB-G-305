#include<stdio.h>

void main(){
    printf("ADDRESS:- \nFlat-506 \nRaghukul Apartment \nNear Gurukruuupa Hotel \nJamnagar \nGujarat \nPincode:- 361006");
}